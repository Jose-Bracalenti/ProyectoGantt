package models.entities;

public enum RolEnum{
    ADMINISTRADOR,
    OPERADOR
}
