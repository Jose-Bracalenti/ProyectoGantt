package models.entities;

public enum FactorRHEnum {
    POSITIVO,
    NEGATIVO
}
