package models.entities;

public enum AccionRealizarEnum {
    CREACION,
    RENOVACION,
    COPIADO
}
