package models.entities;

public enum GrupoSanguineoEnum {
    A,
    O,
    B,
    AB
}
